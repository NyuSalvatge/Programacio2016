#pragma once
#include "GenericSocket.h"

void run() {

	//Abrimos el socket
	GenericSocket xavi_guapo(SOCK_DGRAM);
	//REPRESENTA QUE AQUI S'ESTA EXECUTANT 
	//QUAN SURTS DEL RUN ET TANCA EL SOCKET

}


int main() {
	//Cargamos la utilidad de los sockets
	//SocketTools::Charge();
	//run();
	//DEscargar
	//SocketTools::Download();

	//return 0;

	

}



