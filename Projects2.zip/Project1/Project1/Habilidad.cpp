#include "Habilidad.h"



Habilidad::Habilidad()
{
}


Habilidad::~Habilidad()
{
}
